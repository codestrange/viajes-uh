# Proyecto de Redes de Computadoras - 01

> Base de datos no SQL

* Estamos cansados de las bases de datos SQL, no?
* Estamos cansados de tener que definir un esquema, y cuando tenemos que
  cambiarlo, adicionar código en forma de migraciones, no?
* Queremos correr nuestra base de datos en una computadora disponible de manera
  remota, no?

Aunque la respuesta a todas las preguntas sea no (debería replanteárcelo ;-)), el
primer proyecto de la asignatura de Redes de Computadoras es el de desarrollar
un sistema así. Aunque no tan complejo, este sistema debe ser capás de
comunicarse con la base de datos y realizar las operaciones usuales en esta.

## ¿Qué hay que hacer?

Deben implementar de esta base de datos no SQL dos partes:

* **servidor**: acepta conexiones de diferentes clientes, mantiene el estado de
  la base de datos y ejecuta las acciones provenientes del cliente.
* **cliente**: sabe como conectarse con el servidor y enviarle órdenes.

En esta base de datos los elementos son almacenados sin verificación de
estructura alguna. Pero podemos tener una especie de estructura teniendo
diferentes **colecciones**. Una colección es lo análogo a una tabla en una base
de datos SQL. Una colección es una estructura **llave/valor** en la que las
llaves son elementos sencillos (*int* o *string*) y los valores son diccionarios
tipo *json*.

Un *json* es una estructura que puede tener los siguientes tipos de valores

* *int*
* *string*
* *bool*
* *NoneType* (correspondiente al tipo `None` de *python*)
* *list* no tipadas que pueden contener cualquier tipo de *json*
* *dict* no tipados en los que las llaves son de tipo *string* y los valores de
  tipo *json*.

### Ejemplos de json

```json
// string
"foo"

// int
123

// bool
true

// NoneType
null

// list
[1, "foo"]

// dict
{
    "a": [1, 2, "bla"],
    "b": {
        "c": null,
        "a": 48484
    }
}
```

Los *json* que van a estar almacenados en las colecciones son de la forma

```json
{
    "_key": (string|int),
    // ... el resto del objeto
}
```

El campo `_key` sirve para identificar al objeto en la colección y puede ser
especificado por el usuario, en otro caso se genera automáticamente con los
métodos apropiados.

### ¿Qué tipo de acciones podemos ejecutar en el servidor?

* **ping()**: verifica que el servidor está en funcionamiento.
* **collection_exists(name)**: verifica si la colección con nombre `name` ha
  sido creada.
* **collection(name)**: crea una colección con nombre `name` y prepara el estado
  para que todos los llamados sucesivos utilizen esta colección. Si la colección
  ya existe simplemente prepara el estado.
* **current_collection()**: devuelve el nombre de la colección que está
  siendo utilizada.
* **drop_collection(name)**: elimina la colección con nombre `name`.

Todas las operaciones que vienen a continuación operan sobre la colección que
que se seleccionó utilizando **collection(name)**.

* **get(key)**: devuelve el objeto que tiene en el campo `_key` el valor `key`.
* **create(obj)**: crea el objeto y devuelve el campo `_key` que se utilizó para
  crear este objeto.
* **update(key, obj)**: actualiza el objeto en la colección que tiene en el
  campo `_key` el valor `key`. Esta actualización se debe hacer de manera
  recursiva por cada llave en común entre los dos objetos y agregarla si no
  existe en el anterior.
* **replace(key, obj)**: remplaza el objeto que tiene en el campo `_key` el
  valor `key` por el objeto `obj`.
* **delete(key)**: elimina el objecto que tiene en el campo `_key` el valor `key`.

### Ejemplo de las acciones que se pueden ejecutar

```python
c = Client('localhost:1234')
assert(c.ping())

# Create collection
c.collection('users')

# Check if collection exists
assert(c.collection_exists('users'))

# Data
fulanito = { 'name': 'Fulanito', 'age': 18 }
menganito = { 'name': 'Menganito', 'profession': 'Story teller' }
ciclanito = { '_key': 'ciclanito', 'name': 'ciclanito' }

# Create data
fulanito_key =  c.create(fulanito)  # Return key for object
menganito_key = c.create(menganito)
ciclanito_key = c.create(ciclanito)

assert(c.get(fulanito_key) == {
    '_key': fulanito_key,
    'name': 'Fulanito',
    'age': 18
})

# Create data with custom key
assert(ciclanito_key == 'ciclanito')

c.update(menganito_key, { 'age': 22 })
assert(c.get(menganito_key) == {
    '_key': menganito_key,
    'name': 'Menganito',
    'profession': 'Story teller',
    'age': 22
})

c.replace(ciclanito_key, { 'profession': 'Story listener' })
assert(c.get(ciclanito_key) == {
    '_key': ciclanito_key,
    'profession': 'Story listener'
})

# Delete collection
c.drop_collection('users')
```

### Implementación

En el proyecto hay dos carpetas, una para la implementación del cliente y otra
para la del servidor

```
.
├── client
│   ├── client.py
│   └── test
│       ├── config.py
│       └── ...
├── database.code-workspace
├── docker-compose.yml
├── README.md
└── server
    └── server.py
```

## Anotaciones

* Se deben manejar conexiones simultáneas con varios clientes.
* Las implementaciones de cómo establecer la comunicación con el servidor quedan
  totalmente de parte de ustedes. No imponemos ninguna restricción con el tipo
  de protocolo que quieran utilizar. Aunque si lo vamos a mirar como parte de
  la evaluación.
* Cero fraude. Código 100% propio (lo podemos verificar).

## Dependencias

Para que sea más tranquilo el proceso de desarrollo, es recomendable el uso de docker.
Por eso el colectivo de la asignatura les recomienda, fuera de entrar en muchos detalles de la herramienta, que la utilicen.
De cualquier manera, si alguno se interesa por el tema, puede acercarse a cualquiera de los profesores de la asignatura.

No hay ninguna restricción con respecto a las tecnologías a utilizar (menos utilizar directamente otra base de datos ;-))

En caso de necesitar bibliotecas adicionales utilizar una nueva imagen de python. Por defecto la que se utiliza es `python:3.6-alpine`. Ver a los profesores para este tipo de actividad.

## Run tests

Para correr todos los **tests** del proyecto ejecuten:

```bash
$ docker-compose up
```

La idea es que vean esto:

```
tests_1  | Ran 23 tests in 10.487s
tests_1  | 
tests_1  | OK
```

Si ven algo así:

```
tests_1  | Ran 23 test in 5.341s
tests_1  | 
tests_1  | FAILED (failures=5)
```

busquen dónde están sus errores y corríjanlos.

El proyecto no estará listo hasta que no pasen todos los **tests**. Pero esto
puede estar sujeto a cambios en el futuro de forma que verifiquemos de mejor
manera la calidad de sus resultados.

## Environment

En el archivo `.env` pueden poner todo lo referente a configuración de su servicio, por ejemplo `SERVER_URL`.
Ejemplo para el archivo `.env`:

```bash
$ cat .env
SERVER_URL=db:1234
LOGGING=debug
```

Para acceder a estas variables pueden usar `os.getenv('SERVER_URL')`.

### Variable de entorno `SERVER_URL`

En particular esta variable es utilizada en los tests para instanciar la clase `Client`

```python
Client(os.getenv('SERVER_URL'))
```

La variable debe contener la dirección por la cual el servidor está escuchando. El estudiante es libre de declararla como desee.
Ejemplo:

```bash
SERVER_URL=http://db:1234/mydb
```

También debe tener en cuenta que Docker le asignará al container donde está corriendo el servicio de la base de datos el nombre de dominio `db`. Por lo que si se declara de la forma

```bash
SERVER_URL=db:1234
```

implementaciones del tipo

```python
from socket import socket

class Client(object):
    def __init__(self, server_url):
        host, port = server_url.split(':')
        port = int(port)
        s = socket()
        s.connect((host, port))
```
funcionarán correctamente.
