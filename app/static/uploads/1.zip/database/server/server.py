import socket
import logging

logger = logging.getLogger(__name__)

def configure_logging(args):
    f_handler = logging.FileHandler('server.log')
    f_handler.setLevel(logging.WARNING)

    # Create formatters and add it to handlers
    f_format = logging.Formatter(
        '%(asctime)s %(name)s %(levelname)s %(message)s')
    f_handler.setFormatter(f_format)

    # Add handlers to the logger
    logger.addHandler(f_handler)

    logging.basicConfig(
        format='%(asctime)s %(name)s %(levelname)s %(message)s',
        datefmt='%d-%m-%y %H:%M:%S',
        level=logging.DEBUG)

def main(args):
    configure_logging(args)

    s = socket.socket()
    s.bind(('', args.port))
    s.listen(256)
    logger.info(f'Listening on *:{args.port}')

    """
    Pueden utilizar
    
    * logger.debug
    * logger.info
    * logger.warning
    * logger.error
    * logger.critical
    """

    while True:
        sock, addr = s.accept()
        logger.info(f'connection from {addr} using socket {sock}')


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('-p', '--port', type=int, default=8888)

    # Add all arguments needed

    main(parser.parse_args())
