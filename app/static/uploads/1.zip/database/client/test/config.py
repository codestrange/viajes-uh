from dum_client import DumClient

Client = DumClient