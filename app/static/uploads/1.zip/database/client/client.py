
class Client(object):

    def __init__(self, server_url):
        pass

    def ping(self):
        pass

    def collection_exists(self, name):
        pass

    def collection(self, name):
        pass

    def current_collection(self):
        pass

    def drop_collection(self, name):
        pass

    def get(self, key):
        pass

    def create(self, object):
        pass

    def update(self, key, object):
        pass

    def replace(self, key, object):
        pass

    def delete(self, key):
        pass

class CollectionNotFoundException(Exception):
    pass

class CollectionNotSetException(Exception):
    pass
