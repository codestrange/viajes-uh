from client import Client, CollectionNotFoundException, CollectionNotSetException

import uuid

class DumClient(Client):

    def __init__(self, server_url):
        self._data = {}
        self._coll = None
        self._coll_name = None

    def ping(self):
        return True

    def collection_exists(self, name):
        return name in self._data

    def collection(self, name):
        self._coll_name = name
        self._coll = self._data.setdefault(name, {})
    
    def current_collection(self):
        return self._coll_name
    
    def drop_collection(self, name):
        if not self.collection_exists(name):
            raise CollectionNotFoundException()
        del self._data[name]
    
    def get(self, key):
        if self._coll is None:
            raise CollectionNotSetException()
        return self._coll[key]

    def create(self, obj):
        if self._coll is None:
            raise CollectionNotSetException()
        key = obj.setdefault('_key', uuid.uuid4().hex)
        self._coll[key] = obj
        return key

    def update(self, key, obj):
        if self._coll is None:
            raise CollectionNotSetException()
        self._update(self._coll[key], obj)

    @staticmethod
    def _update(obj, upda):
        for key in upda.keys():
            if key not in obj:
                obj[key] = upda[key]
            elif type(obj[key]) in set((int, str, bool, type(None))):
                obj[key] = upda[key]
            else:
                DumClient._update(obj[key], upda[key])

    def replace(self, key, obj):
        if self._coll is None:
            raise CollectionNotSetException()
        self._coll[key] = obj
        self._coll[key]['_key'] = key
    
    def delete(self, key):
        if self._coll is None:
            raise CollectionNotSetException()
        del self._coll[key]

if __name__ == '__main__':
    c = DumClient('localhost:1234')
    assert(c.ping())

    # Create collection
    c.collection('users')

    # Check if collection exists
    assert(c.collection_exists('users'))

    # Data
    fulanito = { 'name': 'Fulanito', 'age': 18 }
    menganito = { 'name': 'Menganito', 'profession': 'Story teller' }
    ciclanito = { '_key': 'ciclanito', 'name': 'ciclanito' }

    # Create data
    fulanito_key =  c.create(fulanito)  # Return key for object
    menganito_key = c.create(menganito)
    ciclanito_key = c.create(ciclanito)

    assert(c.get(fulanito_key) == { '_key': fulanito_key, 'name': 'Fulanito', 'age': 18 })

    # Create data with custom key
    assert(ciclanito_key == 'ciclanito')

    c.update(menganito_key, { 'age': 22 })
    assert(c.get(menganito_key) == { '_key': menganito_key, 'name': 'Menganito', 'profession': 'Story teller', 'age': 22 })

    c.replace(ciclanito_key, { 'profession': 'Story listener' })
    assert(c.get(ciclanito_key) == { '_key': ciclanito_key, 'profession': 'Story listener' })

    # Delete collection
    c.drop_collection('users')